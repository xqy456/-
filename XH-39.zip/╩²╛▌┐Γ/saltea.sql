/*
 Navicat Premium Data Transfer

 Source Server         : 自己电脑上面的mysql（我自己电脑的数据库）
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : saltea

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 09/01/2024 12:22:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for s_admin
-- ----------------------------
DROP TABLE IF EXISTS `s_admin`;
CREATE TABLE `s_admin`  (
  `account` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `pow` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`account`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of s_admin
-- ----------------------------
INSERT INTO `s_admin` VALUES ('1', '1', '2');
INSERT INTO `s_admin` VALUES ('admin', '123456', '2');
INSERT INTO `s_admin` VALUES ('root', '123456', '1');

-- ----------------------------
-- Table structure for s_rcod
-- ----------------------------
DROP TABLE IF EXISTS `s_rcod`;
CREATE TABLE `s_rcod`  (
  `name` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '奶茶名字',
  `price` int NULL DEFAULT NULL COMMENT '价格',
  `numbers` int UNSIGNED NULL DEFAULT NULL COMMENT '数量',
  `types` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '种类',
  ` account` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '账号'
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of s_rcod
-- ----------------------------
INSERT INTO `s_rcod` VALUES ('青梅绿茶', 50, 1, '1', 'admin');
INSERT INTO `s_rcod` VALUES ('青梅绿茶', 50, 2, '1', 'admin');
INSERT INTO `s_rcod` VALUES ('青梅绿茶', 50, 10, '1', 'admin');
INSERT INTO `s_rcod` VALUES ('青梅绿茶', 50, 10, '1', 'admin');

-- ----------------------------
-- Table structure for s_tea
-- ----------------------------
DROP TABLE IF EXISTS `s_tea`;
CREATE TABLE `s_tea`  (
  `name` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '奶茶名字',
  `price` int NULL DEFAULT NULL COMMENT '价格',
  `numbers` int UNSIGNED NULL DEFAULT NULL COMMENT '数量',
  `types` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '种类',
  PRIMARY KEY (`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of s_tea
-- ----------------------------
INSERT INTO `s_tea` VALUES ('青梅绿茶', 50, 42, '1');

SET FOREIGN_KEY_CHECKS = 1;
